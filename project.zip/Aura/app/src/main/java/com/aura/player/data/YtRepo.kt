package com.aura.player.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File

object YtState {
    /** 0 = loading, 1 = ready, 2 = error */
    val status = MutableStateFlow(0)
    val error = MutableStateFlow<String?>(null)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(ctx: Context) {
        status.value = 0
        error.value = null
        val app = ctx.applicationContext
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                status.value = 1
            } catch (e: Throwable) {
                error.value = e.message ?: e.toString()
                status.value = 2
            }
        }
    }
}

object YtRepo {

    suspend fun ensureReady() {
        if (YtState.status.value == 1) return
        withTimeout(180_000) { YtState.status.first { it != 0 } }
        if (YtState.status.value != 1) {
            throw IllegalStateException(YtState.error.value ?: "yt-dlp is not ready")
        }
    }

    private fun parseItem(j: JSONObject): YtItem? {
        val id = j.str("id")
        if (id.isBlank()) return null
        val page = j.str("webpage_url").ifBlank {
            j.str("url").ifBlank { "https://www.youtube.com/watch?v=$id" }
        }
        val channel = j.str("channel").ifBlank { j.str("uploader") }
        val thumb = j.str("thumbnail").ifBlank { "https://i.ytimg.com/vi/$id/mqdefault.jpg" }
        return YtItem(
            id = id,
            title = j.str("title").ifBlank { id },
            channel = channel,
            durationSec = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
            thumb = if (page.contains("youtube.com") || page.contains("youtu.be")) "https://i.ytimg.com/vi/$id/mqdefault.jpg" else thumb,
            pageUrl = page
        )
    }

    suspend fun search(q: String): List<YtItem> = withContext(Dispatchers.IO) {
        ensureReady()
        val isUrl = q.startsWith("http://") || q.startsWith("https://")
        val req = YoutubeDLRequest(if (isUrl) q else "ytsearch15:$q")
        req.addOption("-j")
        req.addOption("--no-warnings")
        if (isUrl) req.addOption("--no-playlist") else req.addOption("--flat-playlist")
        val out = YoutubeDL.getInstance().execute(req).out
        out.lines().map { it.trim() }.filter { it.startsWith("{") }.mapNotNull {
            try { parseItem(JSONObject(it)) } catch (e: Exception) { null }
        }
    }

    /** Direct stream URL(s). For video this may return 2 URLs: video then audio. */
    suspend fun streamUrls(pageUrl: String, video: Boolean): List<String> = withContext(Dispatchers.IO) {
        ensureReady()
        val req = YoutubeDLRequest(pageUrl)
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("-g")
        req.addOption(
            "-f",
            if (video) "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b" else "bestaudio[ext=m4a]/bestaudio/best"
        )
        val out = YoutubeDL.getInstance().execute(req).out
        val urls = out.lines().map { it.trim() }.filter { it.startsWith("http") }
        if (urls.isEmpty()) throw IllegalStateException("No stream URL found")
        urls
    }

    suspend fun download(ctx: Context, item: YtItem, video: Boolean, onProgress: (Float) -> Unit): Uri? =
        withContext(Dispatchers.IO) {
            ensureReady()
            val dir = File(ctx.cacheDir, "dl_" + System.currentTimeMillis()).apply { mkdirs() }
            val req = YoutubeDLRequest(item.pageUrl)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("-f", if (video) "b[ext=mp4]/b" else "bestaudio[ext=m4a]/bestaudio")
            req.addOption("-o", dir.absolutePath + "/%(title).80s.%(ext)s")
            YoutubeDL.getInstance().execute(req, item.id) { p, _, _ ->
                onProgress((p / 100f).coerceIn(0f, 1f))
            }
            val f = dir.listFiles()?.firstOrNull { it.isFile && !it.name.endsWith(".part") }
                ?: throw IllegalStateException("Download produced no file")
            val uri = saveToMediaStore(ctx, f, item, video)
            dir.deleteRecursively()
            uri
        }

    private fun saveToMediaStore(ctx: Context, f: File, item: YtItem, video: Boolean): Uri? {
        val ext = f.extension.lowercase()
        val mime = if (video) {
            if (ext == "webm") "video/webm" else "video/mp4"
        } else when (ext) {
            "webm" -> "audio/webm"
            "mp3" -> "audio/mpeg"
            "ogg", "opus" -> "audio/ogg"
            else -> "audio/mp4"
        }
        val coll = if (video) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val v = ContentValues()
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/Aura" else "Music/Aura")
        v.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val r = ctx.contentResolver
        val uri = r.insert(coll, v) ?: return null
        r.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        val v2 = ContentValues()
        v2.put(MediaStore.MediaColumns.IS_PENDING, 0)
        r.update(uri, v2, null, null)
        return uri
    }

    /** Updates the bundled yt-dlp (YouTube changes often). Uses reflection to stay compatible across library versions. */
    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        ensureReady()
        val yd = YoutubeDL.getInstance()
        val ms = yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }
        if (ms.isEmpty()) throw IllegalStateException("Update not supported by this library version")
        val one = ms.firstOrNull { it.parameterTypes.size == 1 }
        val r = if (one != null) {
            one.invoke(yd, ctx.applicationContext)
        } else {
            val m2 = ms.first()
            val consts = m2.parameterTypes[1].enumConstants
            val pick = consts?.firstOrNull { it.toString().contains("STABLE", ignoreCase = true) } ?: consts?.firstOrNull()
            m2.invoke(yd, ctx.applicationContext, pick)
        }
        r?.toString() ?: "OK"
    }
}

object Downloads {
    val progress = mutableStateMapOf<String, Float>()
    val done = mutableStateListOf<String>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun key(item: YtItem, video: Boolean) = item.id + (if (video) "_v" else "_a")

    fun start(ctx: Context, item: YtItem, video: Boolean) {
        val k = key(item, video)
        if (progress.containsKey(k)) return
        progress[k] = 0f
        val app = ctx.applicationContext
        toast(app, tr("Download started: ", "بدأ التنزيل: ") + item.title)
        scope.launch {
            try {
                YtRepo.download(app, item, video) { p -> progress[k] = p }
                done.add(k)
                toast(app, tr("Saved to ", "تم الحفظ في ") + (if (video) "Movies/Aura" else "Music/Aura"))
            } catch (e: Throwable) {
                toast(app, tr("Download failed: ", "فشل التنزيل: ") + (e.message ?: ""))
            } finally {
                progress.remove(k)
            }
        }
    }
}

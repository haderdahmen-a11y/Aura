package com.aura.player.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aura.player.MainActivity
import com.aura.player.R

class FloatingVideoService : Service() {
    private var wm: WindowManager? = null
    private var root: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (root == null) show()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("float", "Floating video", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "float")
            .setSmallIcon(R.drawable.ic_play)
            .setContentTitle("Aura")
            .setContentText("Floating video")
            .build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    private fun show() {
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val density = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()
        val themed = ContextThemeWrapper(this, R.style.Theme_Aura)
        val p = VideoHolder.get(this)

        val pv = PlayerView(themed)
        pv.player = p
        pv.useController = false
        pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT

        val frame = FrameLayout(themed)
        frame.setBackgroundColor(Color.BLACK)
        frame.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        fun btn(label: String, gravity: Int, onClick: () -> Unit) {
            val t = TextView(themed)
            t.text = label
            t.setTextColor(Color.WHITE)
            t.textSize = 18f
            t.setPadding(dp(10), dp(6), dp(10), dp(6))
            t.setBackgroundColor(0x88000000.toInt())
            t.setOnClickListener { onClick() }
            frame.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gravity))
        }
        btn("\u2715", Gravity.TOP or Gravity.END) {
            VideoHolder.stop()
            stopSelf()
        }
        btn("\u23EF", Gravity.BOTTOM or Gravity.START) { p.playWhenReady = !p.playWhenReady }
        btn("\u2922", Gravity.TOP or Gravity.START) {
            UiState.resumeVideo = VideoHolder.title.ifBlank { "Video" }
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(i)
            stopSelf()
        }

        val lp = WindowManager.LayoutParams(
            dp(280), dp(158),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(20)
        lp.y = dp(120)

        var sx = 0
        var sy = 0
        var dx = 0f
        var dy = 0f
        frame.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    manager.updateViewLayout(frame, lp)
                    true
                }
                else -> false
            }
        }
        manager.addView(frame, lp)
        root = frame
    }

    override fun onDestroy() {
        try {
            root?.let { wm?.removeView(it) }
        } catch (e: Exception) {
        }
        root = null
        super.onDestroy()
    }
}

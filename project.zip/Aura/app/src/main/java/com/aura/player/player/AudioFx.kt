package com.aura.player.player

import android.Manifest
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.aura.player.AuraApp
import com.aura.player.data.Prefs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Equalizer, bass boost, visualizer and smooth-transition settings. Lives in the same process as PlaybackService. */
object AudioFx {
    const val BARS = 40
    val bars = FloatArray(BARS)

    var available by mutableStateOf(false)
    var vizActive by mutableStateOf(false)
    var eqOn by mutableStateOf(false)
    var bass by mutableIntStateOf(0)
    var fade by mutableStateOf(false)
    var minLevel by mutableIntStateOf(-1500)
    var maxLevel by mutableIntStateOf(1500)
    val freqs = mutableStateListOf<Int>()
    val levels = mutableStateListOf<Int>()

    private var eq: Equalizer? = null
    private var bb: BassBoost? = null
    private var viz: Visualizer? = null
    private var session = 0

    val presets: List<Pair<String, FloatArray>> = listOf(
        "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
        "Bass" to floatArrayOf(0.8f, 0.5f, 0f, -0.1f, 0f),
        "Vocal" to floatArrayOf(-0.3f, 0f, 0.5f, 0.4f, -0.1f),
        "Treble" to floatArrayOf(-0.2f, 0f, 0.1f, 0.5f, 0.8f),
        "Rock" to floatArrayOf(0.6f, 0.2f, -0.2f, 0.4f, 0.6f),
        "Dance" to floatArrayOf(0.7f, 0.3f, 0f, 0.3f, 0.5f)
    )

    fun init() {
        eqOn = Prefs.bool("eqOn", false)
        bass = Prefs.int("bass", 0)
        fade = Prefs.bool("fade", false)
    }

    fun attach(id: Int) {
        if (id == 0) return
        release()
        session = id
        try {
            val e = Equalizer(0, id)
            eq = e
            val n = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            minLevel = range[0].toInt()
            maxLevel = range[1].toInt()
            freqs.clear()
            levels.clear()
            val saved = Prefs.str("eqLevels", "").split(",").mapNotNull { it.toIntOrNull() }
            for (b in 0 until n) {
                freqs.add(e.getCenterFreq(b.toShort()) / 1000)
                levels.add((saved.getOrNull(b) ?: 0).coerceIn(minLevel, maxLevel))
            }
            e.setEnabled(eqOn)
            for (b in 0 until n) e.setBandLevel(b.toShort(), levels[b].toShort())
            available = true
        } catch (t: Throwable) {
            available = false
        }
        try {
            val b = BassBoost(0, id)
            bb = b
            b.setEnabled(bass > 0)
            if (b.strengthSupported) b.setStrength(bass.toShort())
        } catch (t: Throwable) {
        }
        startViz()
    }

    fun setEnabled(on: Boolean) {
        eqOn = on
        Prefs.putBool("eqOn", on)
        try { eq?.setEnabled(on) } catch (t: Throwable) {}
    }

    fun setLevel(band: Int, mb: Int) {
        if (band !in levels.indices) return
        val v = mb.coerceIn(minLevel, maxLevel)
        levels[band] = v
        try { eq?.setBandLevel(band.toShort(), v.toShort()) } catch (t: Throwable) {}
        Prefs.putStr("eqLevels", levels.joinToString(","))
    }

    fun applyPreset(arr: FloatArray) {
        val n = levels.size
        if (n == 0) return
        for (b in 0 until n) {
            val idx = if (n == 1) 0 else (b * 4f / (n - 1)).roundToInt()
            setLevel(b, (arr[idx] * maxLevel * 0.6f).toInt())
        }
    }

    fun setBass(v: Int) {
        bass = v.coerceIn(0, 1000)
        Prefs.putInt("bass", bass)
        try {
            bb?.setEnabled(bass > 0)
            if (bb?.strengthSupported == true) bb?.setStrength(bass.toShort())
        } catch (t: Throwable) {
        }
    }

    fun setFade(on: Boolean) {
        fade = on
        Prefs.putBool("fade", on)
    }

    fun retryViz() { startViz() }

    private fun startViz() {
        try { viz?.release() } catch (t: Throwable) {}
        viz = null
        vizActive = false
        if (session == 0) return
        val granted = ContextCompat.checkSelfPermission(AuraApp.instance, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return
        try {
            val v = Visualizer(session)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) process(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.setEnabled(true)
            viz = v
            vizActive = true
        } catch (t: Throwable) {
            vizActive = false
        }
    }

    private fun process(fft: ByteArray) {
        val n = fft.size / 2
        if (n < 4) return
        for (i in 0 until BARS) {
            val lo = Math.pow(n.toDouble(), i.toDouble() / BARS).toInt().coerceIn(1, n - 1)
            val hi = Math.pow(n.toDouble(), (i + 1).toDouble() / BARS).toInt().coerceIn(lo + 1, n)
            var m = 0f
            for (k in lo until hi) {
                val re = fft[2 * k].toInt()
                val im = fft[2 * k + 1].toInt()
                m = max(m, sqrt((re * re + im * im).toFloat()))
            }
            bars[i] = sqrt((m / 90f).coerceIn(0f, 1f))
        }
    }

    fun release() {
        try { viz?.release() } catch (t: Throwable) {}
        try { eq?.release() } catch (t: Throwable) {}
        try { bb?.release() } catch (t: Throwable) {}
        viz = null; eq = null; bb = null
        vizActive = false
        available = false
    }
}

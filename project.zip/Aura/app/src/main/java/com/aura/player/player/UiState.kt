package com.aura.player.player

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object UiState {
    var inPip by mutableStateOf(false)
    var videoActive by mutableStateOf(false)
    var foreground by mutableStateOf(false)
    var resumeVideo by mutableStateOf<String?>(null)
}

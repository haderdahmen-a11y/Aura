package com.aura.player.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aura.player.data.ImageItem
import com.aura.player.data.MediaRepo
import com.aura.player.data.Song
import com.aura.player.data.VideoItem

class AppState(private val ctx: Context) {
    var songs by mutableStateOf<List<Song>>(emptyList())
    var videos by mutableStateOf<List<VideoItem>>(emptyList())
    var images by mutableStateOf<List<ImageItem>>(emptyList())
    var granted by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var videoTitle by mutableStateOf<String?>(null)
    var photoIndex by mutableIntStateOf(-1)
    var showNow by mutableStateOf(false)
    var showEq by mutableStateOf(false)

    suspend fun refresh() {
        loading = true
        try {
            songs = MediaRepo.songs(ctx)
            videos = MediaRepo.videos(ctx)
            images = MediaRepo.images(ctx)
        } finally {
            loading = false
        }
    }
}

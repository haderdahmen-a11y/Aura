package com.aura.player.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.aura.player.data.Art
import com.aura.player.data.Song
import com.aura.player.data.Stats
import com.aura.player.data.fmt
import com.aura.player.data.tr
import com.aura.player.player.PlayerController
import com.aura.player.player.artOf

@Composable
fun ArtImage(art: Art, modifier: Modifier = Modifier, corner: Dp = 12.dp, sizePx: Int = 256) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, art.songUri) {
        value = if (art.url == null && art.songUri != null) ArtCache.get(ctx, art.songUri, sizePx) else null
    }
    val b = bmp
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color(0xFF3A2A6B), Color(0xFF14323A))))
    ) {
        if (art.url != null) {
            AsyncImage(
                model = art.url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                Icons.Filled.MusicNote, null,
                tint = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.align(Alignment.Center).fillMaxSize(0.4f)
            )
        }
    }
}

/** Blurred, darkened backdrop derived from the cover (tiny bitmap scaled up = soft blur on every Android version). */
@Composable
fun BlurBg(art: Art) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, art.songUri) {
        val big = if (art.url == null && art.songUri != null) ArtCache.get(ctx, art.songUri, 96) else null
        value = big?.let { Bitmap.createScaledBitmap(it, 14, 14, true) }
    }
    val b = bmp
    Box(Modifier.fillMaxSize()) {
        if (art.url != null) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(art.url).size(20).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.Medium,
                modifier = Modifier.fillMaxSize()
            )
        } else if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.Medium,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xAA07070F), Color(0xEE07070F))))
        )
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtImage(Art(songUri = song.uri), Modifier.size(52.dp), 12.dp, 128)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (active) Pal.Accent2 else Color.White,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                song.artist + "  \u2022  " + fmt(song.durationMs),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp
            )
        }
        val fav = Stats.isFav(song.id)
        IconButton(onClick = { Stats.toggleFav(song.id) }) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                tint = if (fav) Pal.Pink else Color.White.copy(alpha = 0.45f)
            )
        }
    }
}

@Composable
fun MiniPlayer(ctrl: PlayerController, onOpen: () -> Unit) {
    val item = ctrl.item ?: return
    val frac = if (ctrl.durationMs > 0) (ctrl.positionMs.toFloat() / ctrl.durationMs).coerceIn(0f, 1f) else 0f
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .glass(22.dp)
            .clickable(onClick = onOpen)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtImage(artOf(item), Modifier.size(44.dp), 10.dp, 96)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.mediaMetadata.title?.toString() ?: "",
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold
                )
                Text(
                    item.mediaMetadata.artist?.toString() ?: "",
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp
                )
            }
            IconButton(onClick = { ctrl.toggle() }) {
                Icon(if (ctrl.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
            }
            IconButton(onClick = { ctrl.next() }) { Icon(Icons.Filled.SkipNext, null) }
        }
        LinearProgressIndicator(
            progress = { frac },
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
            color = Pal.Accent2,
            trackColor = Color.Transparent
        )
    }
}

@Composable
fun GlassField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    onSearch: (() -> Unit)? = null
) {
    Row(
        modifier.glass(16.dp).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = Color.White.copy(alpha = 0.6f))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = Color.White.copy(alpha = 0.4f), maxLines = 1)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Pal.Accent2),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch?.invoke() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (value.isNotEmpty()) {
            IconButton(onClick = { onChange("") }, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Filled.Close, null, tint = Color.White.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Pal.Accent else Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (selected) Color.Black else Color.White, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String = "") {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 6.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        if (subtitle.isNotEmpty()) Text(subtitle, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp)
    }
}

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<ImageVector, String>> = listOf(
        Icons.Filled.LibraryMusic to tr("Library", "المكتبة"),
        Icons.Filled.CloudDownload to "YouTube",
        Icons.Filled.PhotoLibrary to tr("Gallery", "المعرض"),
        Icons.Filled.Settings to tr("Settings", "الإعدادات")
    )
    Row(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .glass(26.dp)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, pair ->
            val col = if (i == selected) Pal.Accent2 else Color.White.copy(alpha = 0.55f)
            Column(
                Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(pair.first, null, tint = col)
                Text(pair.second, fontSize = 11.sp, color = col, maxLines = 1)
            }
        }
    }
}

package com.aura.player.player

import android.app.PendingIntent
import android.content.Intent
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aura.player.MainActivity
import com.aura.player.data.Stats
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        player = p

        p.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                AudioFx.attach(audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                mediaItem?.mediaId?.toLongOrNull()?.let { Stats.onPlayed(it) }
                AuraWidget.refresh(this@PlaybackService)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                AuraWidget.refresh(this@PlaybackService)
            }
        })
        if (p.audioSessionId != C.AUDIO_SESSION_ID_UNSET) AudioFx.attach(p.audioSessionId)

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, p)
            .setCallback(Cb())
            .setSessionActivity(open)
            .build()

        // Smooth transitions (fade in / fade out around track boundaries).
        scope.launch {
            while (isActive) {
                delay(150)
                val pl = player ?: continue
                if (!AudioFx.fade) {
                    if (pl.volume != 1f) pl.volume = 1f
                    continue
                }
                val d = pl.duration
                if (d == C.TIME_UNSET || d <= 0 || !pl.isPlaying) continue
                val pos = pl.currentPosition
                val ms = 3500f
                val fin = (pos / ms).coerceIn(0f, 1f)
                val fout = ((d - pos) / ms).coerceIn(0f, 1f)
                pl.volume = minOf(fin, fout).coerceIn(0.05f, 1f)
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val pl = session?.player
        if (pl == null || !pl.playWhenReady || pl.mediaItemCount == 0 || pl.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        session?.run {
            player.release()
            release()
        }
        session = null
        player = null
        AudioFx.release()
        super.onDestroy()
    }

    private class Cb : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val updated = mediaItems.map {
                val uri = it.requestMetadata.mediaUri ?: it.localConfiguration?.uri
                it.buildUpon().setUri(uri).build()
            }.toMutableList()
            return Futures.immediateFuture(updated)
        }
    }

    companion object {
        @Volatile
        var player: ExoPlayer? = null
    }
}

object SleepTimer {
    val remainingMs = MutableStateFlow(0L)
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun start(minutes: Int) {
        cancel()
        val end = SystemClock.elapsedRealtime() + minutes * 60_000L
        job = scope.launch {
            while (true) {
                val left = end - SystemClock.elapsedRealtime()
                remainingMs.value = left.coerceAtLeast(0L)
                if (left <= 0L) break
                delay(1000)
            }
            PlaybackService.player?.pause()
            remainingMs.value = 0L
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        remainingMs.value = 0L
    }
}

package com.aura.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import coil.compose.AsyncImage
import com.aura.player.data.Downloads
import com.aura.player.data.YtItem
import com.aura.player.data.YtRepo
import com.aura.player.data.YtState
import com.aura.player.data.fmt
import com.aura.player.data.toast
import com.aura.player.data.tr
import com.aura.player.player.PlayerController
import com.aura.player.player.VideoHolder
import kotlinx.coroutines.launch

@Composable
fun YoutubeScreen(app: AppState, ctrl: PlayerController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<YtItem>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    val st by YtState.status.collectAsState()
    val err by YtState.error.collectAsState()

    fun doSearch() {
        if (q.isBlank() || busy) return
        busy = true
        scope.launch {
            try {
                results = YtRepo.search(q.trim())
                if (results.isEmpty()) toast(ctx, tr("No results", "لا نتائج"))
            } catch (e: Throwable) {
                toast(ctx, tr("Search failed: ", "فشل البحث: ") + (e.message ?: ""))
            } finally {
                busy = false
            }
        }
    }

    fun watch(item: YtItem) {
        if (busy) return
        busy = true
        scope.launch {
            try {
                val urls = YtRepo.streamUrls(item.pageUrl, true)
                VideoHolder.playRemote(ctx, urls, item.title)
                app.videoTitle = item.title
            } catch (e: Throwable) {
                toast(ctx, tr("Could not load video: ", "تعذر تحميل الفيديو: ") + (e.message ?: ""))
            } finally {
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("YouTube", tr("Search, stream and download with yt-dlp", "ابحث وشغّل ونزّل عبر yt-dlp"))
        GlassField(
            value = q, onChange = { q = it },
            hint = tr("Search or paste a link", "ابحث أو الصق رابطاً"),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            onSearch = { doSearch() }
        )
        Spacer(Modifier.height(8.dp))

        if (st == 0) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Pal.Accent2)
                Spacer(Modifier.width(10.dp))
                Text(tr("Preparing yt-dlp engine (first launch takes a moment)…", "جارٍ تجهيز محرك yt-dlp (أول مرة تستغرق وقتاً)…"), fontSize = 13.sp)
            }
        } else if (st == 2) {
            Column(Modifier.padding(16.dp)) {
                Text(tr("yt-dlp engine failed to start: ", "تعذر تشغيل محرك yt-dlp: ") + (err ?: ""), color = Pal.Pink, fontSize = 13.sp)
                TextButton(onClick = { YtState.init(ctx) }) { Text(tr("Retry", "إعادة المحاولة")) }
            }
        }
        if (busy || ctrl.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Pal.Accent2)

        LazyColumn(Modifier.fillMaxSize()) {
            items(results, key = { it.id + it.pageUrl }) { item ->
                YtRow(
                    item,
                    onAudio = { scope.launch { ctrl.playYt(item) } },
                    onVideo = { watch(item) },
                    onDownload = { video -> Downloads.start(ctx, item, video) }
                )
            }
        }
    }
}

@Composable
private fun YtRow(item: YtItem, onAudio: () -> Unit, onVideo: () -> Unit, onDownload: (Boolean) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val pa = Downloads.progress[Downloads.key(item, false)]
    val pv = Downloads.progress[Downloads.key(item, true)]
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 120.dp, height = 68.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.08f))) {
                AsyncImage(
                    model = item.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (item.durationSec > 0) {
                    Text(
                        fmt(item.durationSec * 1000), fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                            .background(Color(0xAA000000), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(item.channel, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = onAudio) { Icon(Icons.Filled.PlayArrow, null, tint = Pal.Accent2) }
            IconButton(onClick = onVideo) { Icon(Icons.Filled.Videocam, null, tint = Pal.Accent) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.Download, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(tr("Download audio (m4a)", "تنزيل الصوت (m4a)")) }, onClick = { menu = false; onDownload(false) })
                    DropdownMenuItem(text = { Text(tr("Download video (mp4)", "تنزيل الفيديو (mp4)")) }, onClick = { menu = false; onDownload(true) })
                }
            }
        }
        val p = pa ?: pv
        if (p != null) {
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Pal.Accent2)
        }
    }
}

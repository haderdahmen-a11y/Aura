package com.aura.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Subject
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.OutlinedTextField
import androidx.media3.common.Player
import com.aura.player.data.Art
import com.aura.player.data.Lyrics
import com.aura.player.data.LyricsRepo
import com.aura.player.data.Stats
import com.aura.player.data.fmt
import com.aura.player.data.tr
import com.aura.player.player.AudioFx
import com.aura.player.player.PlayerController
import com.aura.player.player.SleepTimer
import com.aura.player.player.artOf
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun NowPlayingScreen(ctrl: PlayerController, onClose: () -> Unit, onEq: () -> Unit) {
    BackHandler { onClose() }
    val item = ctrl.item
    val art = artOf(item)
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var showSleep by remember { mutableStateOf(false) }
    val remaining by SleepTimer.remainingMs.collectAsState()
    val localId = item?.mediaId?.toLongOrNull()

    Box(Modifier.fillMaxSize().background(Pal.Bg1)) {
        BlurBg(art)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(32.dp)) }
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(tr("Now playing", "قيد التشغيل"), fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = onEq) { Icon(Icons.Filled.Tune, null) }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (mode == 0) VisualizerPane(ctrl, art) else LyricsPane(ctrl)
            }

            Text(
                item?.mediaMetadata?.title?.toString() ?: "",
                fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                item?.mediaMetadata?.artist?.toString() ?: "",
                color = Color.White.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )

            // Seek bar (always left-to-right)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                var drag by remember { mutableStateOf<Float?>(null) }
                val dur = ctrl.durationMs.coerceAtLeast(1L)
                Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Slider(
                        value = drag ?: (ctrl.positionMs.toFloat() / dur).coerceIn(0f, 1f),
                        onValueChange = { drag = it },
                        onValueChangeFinished = {
                            drag?.let { ctrl.seekTo((it * dur).toLong()) }
                            drag = null
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Pal.Accent2,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        )
                    )
                    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
                        Text(fmt(((drag ?: 0f) * dur).toLong().takeIf { drag != null } ?: ctrl.positionMs), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                        Spacer(Modifier.weight(1f))
                        Text(fmt(ctrl.durationMs), fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { ctrl.toggleShuffle() }) {
                        Icon(Icons.Filled.Shuffle, null, tint = if (ctrl.shuffleOn) Pal.Accent2 else Color.White.copy(alpha = 0.7f))
                    }
                    IconButton(onClick = { ctrl.prev() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Filled.SkipPrevious, null, Modifier.size(38.dp))
                    }
                    Box(
                        Modifier.size(72.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Pal.Accent, Pal.Accent2)))
                            .clickable { ctrl.toggle() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (ctrl.loading) {
                            CircularProgressIndicator(color = Color.Black, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
                        } else {
                            Icon(
                                if (ctrl.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                                tint = Color.Black, modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                    IconButton(onClick = { ctrl.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Filled.SkipNext, null, Modifier.size(38.dp))
                    }
                    IconButton(onClick = { ctrl.toggleRepeat() }) {
                        Icon(
                            if (ctrl.repeatState == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null,
                            tint = if (ctrl.repeatState != Player.REPEAT_MODE_OFF) Pal.Accent2 else Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { mode = if (mode == 0) 1 else 0 }) {
                    Icon(if (mode == 0) Icons.Filled.Subject else Icons.Filled.GraphicEq, null, tint = Pal.Accent2)
                }
                IconButton(onClick = { showSleep = true }) {
                    Icon(Icons.Filled.Bedtime, null, tint = if (remaining > 0) Pal.Accent2 else Color.White.copy(alpha = 0.7f))
                }
                if (localId != null) {
                    val fav = Stats.isFav(localId)
                    IconButton(onClick = { Stats.toggleFav(localId) }) {
                        Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (fav) Pal.Pink else Color.White.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
    if (showSleep) SleepDialog(remaining) { showSleep = false }
}

@Composable
private fun SleepDialog(remaining: Long, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B1038),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        confirmButton = {},
        title = { Text(tr("Sleep timer", "مؤقت النوم")) },
        text = {
            Column {
                if (remaining > 0) {
                    Text(tr("Stops in ", "يتوقف بعد ") + fmt(remaining), color = Pal.Accent2, modifier = Modifier.padding(bottom = 8.dp))
                }
                listOf(15, 30, 45, 60, 90).forEach { m ->
                    TextButton(onClick = { SleepTimer.start(m); onDismiss() }) {
                        Text("$m " + tr("minutes", "دقيقة"))
                    }
                }
                TextButton(onClick = { SleepTimer.cancel(); onDismiss() }) { Text(tr("Turn off", "إيقاف")) }
            }
        }
    )
}

@Composable
private fun VisualizerPane(ctrl: PlayerController, art: Art) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        ArtImage(
            art,
            Modifier.fillMaxWidth(0.72f).aspectRatio(1f)
                .shadow(28.dp, RoundedCornerShape(28.dp), ambientColor = Pal.Accent, spotColor = Pal.Accent),
            28.dp, 640
        )
        Spacer(Modifier.height(28.dp))
        WaveBars(ctrl.isPlaying, Modifier.fillMaxWidth().height(96.dp))
    }
}

@Composable
private fun WaveBars(playing: Boolean, modifier: Modifier) {
    val n = AudioFx.BARS
    val smooth = remember { FloatArray(n) }
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) withFrameNanos { t = it / 1_000_000_000f }
    }
    Canvas(modifier) {
        val tt = t
        val real = AudioFx.vizActive && playing
        val bw = size.width / (n * 1.5f)
        val gap = bw * 0.5f
        val mid = size.height / 2f
        for (i in 0 until n) {
            val env = (1f - abs(i - n / 2f) / (n / 1.5f)).coerceIn(0.25f, 1f)
            val target = when {
                !playing -> 0.04f
                real -> AudioFx.bars[i]
                else -> ((0.30f + 0.28f * sin(tt * 3.1f + i * 0.55f) + 0.18f * sin(tt * 5.7f + i * 1.3f) + 0.12f * sin(tt * 1.7f - i * 0.2f)) * env).coerceIn(0.05f, 1f)
            }
            smooth[i] += (target - smooth[i]) * 0.35f
            val h = (smooth[i] * size.height).coerceAtLeast(4f)
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Pal.Accent2, Pal.Accent, Pal.Pink),
                    startY = mid - h / 2f, endY = mid + h / 2f
                ),
                topLeft = Offset(i * (bw + gap), mid - h / 2f),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

@Composable
private fun LyricsPane(ctrl: PlayerController) {
    val item = ctrl.item ?: return
    val ctx = LocalContext.current
    var lyrics by remember(item.mediaId) { mutableStateOf<Lyrics?>(null) }
    var status by remember(item.mediaId) { mutableIntStateOf(0) }
    var custom by remember(item.mediaId) { mutableStateOf<String?>(null) }
    var showSearch by remember { mutableStateOf(false) }

    LaunchedEffect(item.mediaId, custom) {
        status = 0
        lyrics = null
        val title = item.mediaMetadata.title?.toString() ?: ""
        val artist = item.mediaMetadata.artist?.toString() ?: ""
        lyrics = LyricsRepo.load(ctx, title, artist, ctrl.durationMs, custom)
        status = if (lyrics == null) 2 else 1
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val l = lyrics
            when {
                status == 0 -> CircularProgressIndicator(color = Pal.Accent2, modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                l == null -> Text(
                    tr("No lyrics found for this song", "لم أجد كلمات لهذه الأغنية"),
                    color = Color.White.copy(alpha = 0.6f), textAlign = TextAlign.Center
                )
                else -> {
                    val pos = ctrl.positionMs
                    val active = if (l.synced) l.lines.indexOfLast { it.timeMs <= pos + 250 } else -1
                    val state = rememberLazyListState()
                    LaunchedEffect(active) {
                        if (l.synced && active >= 0) state.animateScrollToItem((active - 2).coerceAtLeast(0))
                    }
                    LazyColumn(state = state, modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        itemsIndexed(l.lines) { idx, line ->
                            Text(
                                if (line.text.isBlank()) "\u266A" else line.text,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                color = Color.White.copy(alpha = if (!l.synced || idx == active) 1f else 0.35f),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                                    .clickable(enabled = l.synced) { ctrl.seekTo(line.timeMs) }
                            )
                        }
                    }
                }
            }
        }
        TextButton(onClick = { showSearch = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text(tr("Wrong lyrics? Search manually", "كلمات خاطئة؟ ابحث يدوياً"), color = Pal.Accent2, fontSize = 13.sp)
        }
    }

    if (showSearch) {
        var text by remember { mutableStateOf((item.mediaMetadata.title?.toString() ?: "") + " " + (item.mediaMetadata.artist?.toString() ?: "")) }
        AlertDialog(
            onDismissRequest = { showSearch = false },
            containerColor = Color(0xFF1B1038),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text(tr("Search lyrics", "ابحث عن الكلمات")) },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = { custom = text.trim(); showSearch = false }) { Text(tr("Search", "بحث")) }
            },
            dismissButton = {
                TextButton(onClick = { showSearch = false }) { Text(tr("Cancel", "إلغاء")) }
            }
        )
    }
}

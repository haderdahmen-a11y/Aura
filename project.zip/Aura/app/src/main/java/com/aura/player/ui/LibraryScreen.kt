package com.aura.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Update
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aura.player.data.Art
import com.aura.player.data.Song
import com.aura.player.data.Stats
import com.aura.player.data.tr
import com.aura.player.player.PlayerController

private class SmartList(val title: String, val icon: ImageVector, val build: () -> List<Song>)

@Composable
fun LibraryScreen(app: AppState, ctrl: PlayerController) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var group by remember { mutableStateOf<Pair<String, List<Song>>?>(null) }
    BackHandler(enabled = group != null) { group = null }

    val all = app.songs
    val songs = remember(all, query) {
        if (query.isBlank()) all else all.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }

    val g = group
    if (g != null) {
        GroupScreen(g.first, g.second, ctrl) { group = null }
        return
    }

    val activeId = ctrl.item?.mediaId

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Aura", tr("${all.size} songs", "${all.size} أغنية"))
        GlassField(
            value = query, onChange = { query = it },
            hint = tr("Search songs, artists, albums", "ابحث عن أغنية أو فنان أو ألبوم"),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        val tabs = listOf(
            tr("Songs", "الأغاني"), tr("Albums", "الألبومات"), tr("Artists", "الفنانون"),
            tr("Folders", "المجلدات"), tr("Smart", "قوائم ذكية")
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabs.size) { i -> Pill(tabs[i], tab == i) { tab = i } }
        }

        if (all.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (app.loading) tr("Loading…", "جارٍ التحميل…")
                    else tr("No music found on this device", "لا توجد موسيقى على الجهاز"),
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
            return@Column
        }

        when (tab) {
            0 -> LazyColumn(Modifier.fillMaxSize()) {
                items(songs, key = { it.id }) { s ->
                    SongRow(s, s.id.toString() == activeId) {
                        ctrl.playQueue(songs, songs.indexOf(s))
                    }
                }
            }

            1 -> {
                val albums = remember(songs) { songs.groupBy { it.album }.toList().sortedBy { it.first.lowercase() } }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(albums) { (name, list) ->
                        Column(Modifier.clickable { group = name to list }) {
                            ArtImage(Art(songUri = list.first().uri), Modifier.fillMaxWidth().aspectRatio(1f), 18.dp, 400)
                            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                            Text(
                                list.first().artist + "  \u2022  " + list.size,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            2 -> {
                val artists = remember(songs) { songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() } }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(artists) { (name, list) -> GroupRow(name, list.size, Icons.Filled.Person) { group = name to list } }
                }
            }

            3 -> {
                val folders = remember(songs) { songs.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() } }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(folders) { (name, list) -> GroupRow(name, list.size, Icons.Filled.Folder) { group = name to list } }
                }
            }

            else -> {
                val smart = listOf(
                    SmartList(tr("Most played", "الأكثر استماعاً"), Icons.Filled.TrendingUp) {
                        all.filter { Stats.count(it.id) > 0 }.sortedByDescending { Stats.count(it.id) }.take(60)
                    },
                    SmartList(tr("Recently added", "المضاف حديثاً"), Icons.Filled.Update) {
                        all.sortedByDescending { it.dateAdded }.take(60)
                    },
                    SmartList(tr("Recently played", "استُمع إليها مؤخراً"), Icons.Filled.History) {
                        all.filter { Stats.last(it.id) > 0 }.sortedByDescending { Stats.last(it.id) }.take(60)
                    },
                    SmartList(tr("Favorites", "المفضلة"), Icons.Filled.Favorite) {
                        all.filter { Stats.isFav(it.id) }
                    },
                    SmartList(tr("Downloaded with Aura", "تنزيلات Aura"), Icons.Filled.CloudDownload) {
                        all.filter { it.folder.contains("Aura") }
                    }
                )
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(smart) { s ->
                        val n = s.build().size
                        Row(
                            Modifier.fillMaxWidth().glass(20.dp).clickable { group = s.title to s.build() }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(s.icon, null, tint = Pal.Accent2, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                Text(tr("$n songs", "$n أغنية"), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupRow(name: String, count: Int, icon: ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Pal.Accent) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(tr("$count songs", "$count أغنية"), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
        }
    }
}

@Composable
fun GroupScreen(title: String, list: List<Song>, ctrl: PlayerController, onBack: () -> Unit) {
    val activeId = ctrl.item?.mediaId
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { ctrl.playQueue(list, 0) },
                colors = ButtonDefaults.buttonColors(containerColor = Pal.Accent, contentColor = Color.Black)
            ) {
                Icon(Icons.Filled.PlayArrow, null)
                Text(tr("Play", "تشغيل"))
            }
            Button(
                onClick = { ctrl.playQueue(list, 0, shuffle = true) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f), contentColor = Color.White)
            ) {
                Icon(Icons.Filled.Shuffle, null)
                Text(tr("Shuffle", "عشوائي"))
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("Nothing here yet", "لا شيء هنا بعد"), color = Color.White.copy(alpha = 0.55f))
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.id }) { s ->
                    SongRow(s, s.id.toString() == activeId) { ctrl.playQueue(list, list.indexOf(s)) }
                }
            }
        }
    }
}

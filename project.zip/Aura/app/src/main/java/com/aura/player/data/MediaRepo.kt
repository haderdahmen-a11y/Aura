package com.aura.player.data

import android.content.Context
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AM
import android.provider.MediaStore.Images.Media as IM
import android.provider.MediaStore.Video.Media as VM
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MediaRepo {

    suspend fun songs(ctx: Context): List<Song> = withContext(Dispatchers.IO) {
        val res = ArrayList<Song>()
        val proj = arrayOf(
            AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID,
            AM.DURATION, AM.DATE_ADDED, AM.RELATIVE_PATH
        )
        try {
            ctx.contentResolver.query(AM.EXTERNAL_CONTENT_URI, proj, "${AM.DURATION} >= 15000", null, null)?.use { c ->
                val iId = c.getColumnIndexOrThrow(AM._ID)
                val iTitle = c.getColumnIndexOrThrow(AM.TITLE)
                val iArtist = c.getColumnIndexOrThrow(AM.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(AM.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(AM.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(AM.DURATION)
                val iAdded = c.getColumnIndexOrThrow(AM.DATE_ADDED)
                val iPath = c.getColumnIndexOrThrow(AM.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val rawArtist = c.getString(iArtist) ?: ""
                    val artist = if (rawArtist.isBlank() || rawArtist == "<unknown>") tr("Unknown artist", "فنان غير معروف") else rawArtist
                    val rawAlbum = c.getString(iAlbum) ?: ""
                    val album = if (rawAlbum.isBlank()) tr("Unknown album", "ألبوم غير معروف") else rawAlbum
                    res.add(
                        Song(
                            id = c.getLong(iId),
                            title = c.getString(iTitle) ?: "",
                            artist = artist,
                            album = album,
                            albumId = c.getLong(iAlbumId),
                            durationMs = c.getLong(iDur),
                            dateAdded = c.getLong(iAdded),
                            folder = (c.getString(iPath) ?: "").trimEnd('/').ifBlank { "/" }
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        res.sortedBy { it.title.lowercase() }
    }

    suspend fun videos(ctx: Context): List<VideoItem> = withContext(Dispatchers.IO) {
        val res = ArrayList<VideoItem>()
        val proj = arrayOf(VM._ID, VM.DISPLAY_NAME, VM.DURATION)
        try {
            ctx.contentResolver.query(VM.EXTERNAL_CONTENT_URI, proj, null, null, "${VM.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(VM._ID)
                val iName = c.getColumnIndexOrThrow(VM.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(VM.DURATION)
                while (c.moveToNext()) {
                    res.add(VideoItem(c.getLong(iId), c.getString(iName) ?: "", c.getLong(iDur)))
                }
            }
        } catch (e: Exception) {
        }
        res
    }

    suspend fun images(ctx: Context): List<ImageItem> = withContext(Dispatchers.IO) {
        val res = ArrayList<ImageItem>()
        val proj = arrayOf(IM._ID, IM.DISPLAY_NAME)
        try {
            ctx.contentResolver.query(IM.EXTERNAL_CONTENT_URI, proj, null, null, "${IM.DATE_ADDED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(IM._ID)
                val iName = c.getColumnIndexOrThrow(IM.DISPLAY_NAME)
                while (c.moveToNext()) {
                    res.add(ImageItem(c.getLong(iId), c.getString(iName) ?: ""))
                }
            }
        } catch (e: Exception) {
        }
        res
    }
}

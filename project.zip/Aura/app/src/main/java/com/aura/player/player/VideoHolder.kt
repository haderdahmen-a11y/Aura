package com.aura.player.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource

/** One shared video player used by the in-app video screen and the floating window. */
object VideoHolder {
    var player: ExoPlayer? = null
    var title: String = ""

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val p = ExoPlayer.Builder(ctx.applicationContext).setAudioAttributes(attrs, true).build()
        player = p
        return p
    }

    fun playLocal(ctx: Context, uri: Uri, name: String) {
        title = name
        val p = get(ctx)
        p.setMediaItem(MediaItem.fromUri(uri))
        p.prepare()
        p.playWhenReady = true
    }

    fun playRemote(ctx: Context, urls: List<String>, name: String) {
        title = name
        val p = get(ctx)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
        val f = ProgressiveMediaSource.Factory(http)
        val src = if (urls.size >= 2) {
            MergingMediaSource(
                f.createMediaSource(MediaItem.fromUri(urls[0])),
                f.createMediaSource(MediaItem.fromUri(urls[1]))
            )
        } else {
            f.createMediaSource(MediaItem.fromUri(urls[0]))
        }
        p.setMediaSource(src)
        p.prepare()
        p.playWhenReady = true
    }

    fun stop() {
        player?.stop()
        player?.clearMediaItems()
    }
}

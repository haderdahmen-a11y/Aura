package com.aura.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.aura.player.data.Lang

object Pal {
    val Bg1 = Color(0xFF07070F)
    val Bg2 = Color(0xFF1B1038)
    val Accent = Color(0xFF9B8CFF)
    val Accent2 = Color(0xFF38E8C6)
    val Pink = Color(0xFFFF6FB5)
}

@Composable
fun AuraTheme(content: @Composable () -> Unit) {
    val dir = if (Lang.isAr) LayoutDirection.Rtl else LayoutDirection.Ltr
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Accent,
            secondary = Pal.Accent2,
            background = Pal.Bg1,
            surface = Pal.Bg1,
            onSurface = Color.White,
            onBackground = Color.White,
            onPrimary = Color.Black
        )
    ) {
        CompositionLocalProvider(
            LocalContentColor provides Color.White,
            LocalLayoutDirection provides dir
        ) { content() }
    }
}

/** Frosted-glass look: translucent gradient fill + bright hairline border. */
fun Modifier.glass(corner: Dp = 20.dp): Modifier {
    val shape = RoundedCornerShape(corner)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.13f), Color.White.copy(alpha = 0.05f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.32f), Color.White.copy(alpha = 0.04f))),
            shape
        )
}

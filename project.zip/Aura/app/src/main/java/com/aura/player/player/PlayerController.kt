package com.aura.player.player

import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aura.player.data.Art
import com.aura.player.data.Song
import com.aura.player.data.YtItem
import com.aura.player.data.YtRepo
import com.aura.player.data.toast
import com.aura.player.data.tr
import kotlin.random.Random

fun artOf(item: MediaItem?): Art {
    if (item == null) return Art()
    val id = item.mediaId.toLongOrNull()
    return if (id != null) {
        Art(songUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id))
    } else {
        Art(url = item.mediaMetadata.artworkUri?.toString())
    }
}

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(Uri.parse("content://media/external/audio/albumart/$albumId"))
            .build()
    )
    .build()

class PlayerController(private val ctx: Context) {
    private var c: MediaController? = null

    var ready by mutableStateOf(false)
    var isPlaying by mutableStateOf(false)
    var item by mutableStateOf<MediaItem?>(null)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)
    var shuffleOn by mutableStateOf(false)
    var repeatState by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var loading by mutableStateOf(false)

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@PlayerController.isPlaying = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            item = mediaItem
            positionMs = 0L
            syncDuration()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncDuration()
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            item = c?.currentMediaItem
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            shuffleOn = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            repeatState = repeatMode
        }

        override fun onPlayerError(error: PlaybackException) {
            toast(ctx, tr("Playback error: ", "خطأ في التشغيل: ") + (error.message ?: ""))
        }
    }

    init {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            try {
                onConnected(f.get())
            } catch (e: Exception) {
                toast(ctx, "Player connection failed")
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    private fun onConnected(mc: MediaController) {
        c = mc
        mc.addListener(listener)
        item = mc.currentMediaItem
        isPlaying = mc.isPlaying
        shuffleOn = mc.shuffleModeEnabled
        repeatState = mc.repeatMode
        positionMs = mc.currentPosition
        syncDuration()
        ready = true
    }

    private fun syncDuration() {
        val mc = c ?: return
        val d = mc.duration
        durationMs = if (d == C.TIME_UNSET || d < 0) 0L else d
    }

    fun tick() {
        val mc = c ?: return
        positionMs = mc.currentPosition
        val d = mc.duration
        if (d != C.TIME_UNSET && d >= 0 && d != durationMs) durationMs = d
    }

    fun playQueue(songs: List<Song>, index: Int, shuffle: Boolean = false) {
        val mc = c
        if (mc == null) {
            toast(ctx, tr("Player is starting, try again", "المشغل قيد التشغيل، حاول مجدداً"))
            return
        }
        val n = songs.size
        if (n == 0) return
        val start = if (shuffle) Random.nextInt(n) else index.coerceIn(0, n - 1)
        val cnt = minOf(n, 300)
        val q = (0 until cnt).map { songs[(start + it) % n].toMediaItem() }
        if (shuffle) mc.shuffleModeEnabled = true
        mc.setMediaItems(q, 0, 0L)
        mc.prepare()
        mc.play()
    }

    suspend fun playYt(y: YtItem) {
        val mc = c
        if (mc == null) {
            toast(ctx, tr("Player is starting, try again", "المشغل قيد التشغيل، حاول مجدداً"))
            return
        }
        loading = true
        try {
            val url = YtRepo.streamUrls(y.pageUrl, false).first()
            val uri = Uri.parse(url)
            val mi = MediaItem.Builder()
                .setMediaId("yt:" + y.id)
                .setUri(uri)
                .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(y.title)
                        .setArtist(y.channel)
                        .setArtworkUri(Uri.parse(y.thumb))
                        .build()
                )
                .build()
            mc.setMediaItem(mi)
            mc.prepare()
            mc.play()
        } catch (e: Throwable) {
            toast(ctx, tr("Could not load: ", "تعذر التحميل: ") + (e.message ?: ""))
        } finally {
            loading = false
        }
    }

    fun toggle() {
        val mc = c ?: return
        if (mc.isPlaying) mc.pause() else mc.play()
    }

    fun next() { c?.seekToNext() }
    fun prev() { c?.seekToPrevious() }
    fun seekTo(ms: Long) { c?.seekTo(ms); positionMs = ms }

    fun toggleShuffle() {
        val mc = c ?: return
        mc.shuffleModeEnabled = !mc.shuffleModeEnabled
    }

    fun toggleRepeat() {
        val mc = c ?: return
        mc.repeatMode = when (mc.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
}

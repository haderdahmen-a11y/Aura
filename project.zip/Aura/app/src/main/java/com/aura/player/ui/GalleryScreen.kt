package com.aura.player.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.aura.player.MainActivity
import com.aura.player.data.ImageItem
import com.aura.player.data.fmt
import com.aura.player.data.toast
import com.aura.player.data.tr
import com.aura.player.player.FloatingVideoService
import com.aura.player.player.UiState
import com.aura.player.player.VideoHolder
import kotlinx.coroutines.delay

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun GalleryScreen(app: AppState) {
    val ctx = LocalContext.current
    var sub by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle(tr("Gallery", "المعرض"), tr("${app.videos.size} videos  \u2022  ${app.images.size} photos", "${app.videos.size} فيديو  \u2022  ${app.images.size} صورة"))
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(tr("Videos", "الفيديوهات"), sub == 0) { sub = 0 }
            Pill(tr("Photos", "الصور"), sub == 1) { sub = 1 }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (sub == 0) {
                items(app.videos, key = { it.id }) { v ->
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.08f))
                            .clickable {
                                VideoHolder.playLocal(ctx, v.uri, v.name)
                                app.videoTitle = v.name
                            }
                    ) {
                        AsyncImage(model = v.uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Text(
                            fmt(v.durationMs), fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                                .background(Color(0xAA000000), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            } else {
                items(app.images.size) { i ->
                    val img = app.images[i]
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.08f))
                            .clickable { app.photoIndex = i }
                    ) {
                        AsyncImage(model = img.uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(title: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val holder = remember { arrayOfNulls<PlayerView>(1) }
    DisposableEffect(Unit) {
        UiState.videoActive = true
        onDispose {
            UiState.videoActive = false
            holder[0]?.player = null
        }
    }
    BackHandler { VideoHolder.player?.pause(); onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = VideoHolder.get(c)
                    useController = true
                    holder[0] = this
                }
            },
            update = { it.useController = !UiState.inPip },
            modifier = Modifier.fillMaxSize()
        )
        if (!UiState.inPip) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp).background(Color(0x66000000)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { VideoHolder.player?.pause(); onClose() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    val a = ctx.findActivity()
                    if (a != null) {
                        a.requestedOrientation =
                            if (a.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    }
                }) { Icon(Icons.Filled.ScreenRotation, null) }
                IconButton(onClick = { (ctx.findActivity() as? MainActivity)?.enterPip() }) {
                    Icon(Icons.Filled.PictureInPictureAlt, null)
                }
                IconButton(onClick = {
                    if (!Settings.canDrawOverlays(ctx)) {
                        toast(ctx, tr("Allow \"Display over other apps\" for Aura, then try again", "اسمح لـ Aura بـ «الظهور فوق التطبيقات» ثم أعد المحاولة"))
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } else {
                        ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingVideoService::class.java))
                        ctx.findActivity()?.moveTaskToBack(true)
                        onClose()
                    }
                }) { Icon(Icons.Filled.Layers, null) }
            }
        }
    }
}

@Composable
fun PhotoViewer(images: List<ImageItem>, start: Int, onClose: () -> Unit) {
    BackHandler { onClose() }
    if (images.isEmpty()) { onClose(); return }
    val pager = rememberPagerState(initialPage = start.coerceIn(0, images.size - 1)) { images.size }
    var zoomed by remember { mutableStateOf(false) }
    var slide by remember { mutableStateOf(false) }
    LaunchedEffect(slide) {
        while (slide) {
            delay(3000)
            if (!slide) break
            pager.animateScrollToPage((pager.currentPage + 1) % images.size)
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize()) { page ->
            ZoomableImage(images[page].uri) { zoomed = it }
        }
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().background(Color(0x66000000)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text("${pager.currentPage + 1} / ${images.size}", modifier = Modifier.weight(1f))
            IconButton(onClick = { slide = !slide }) {
                Icon(if (slide) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = if (slide) Pal.Accent2 else Color.White)
            }
        }
    }
}

@Composable
private fun ZoomableImage(uri: Uri, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    AsyncImage(
        model = uri,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var go = true
                    while (go) {
                        val ev = awaitPointerEvent()
                        if (ev.changes.size >= 2 || scale > 1f) {
                            val z = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            scale = (scale * z).coerceIn(1f, 5f)
                            val mx = size.width * (scale - 1f) / 2f
                            val my = size.height * (scale - 1f) / 2f
                            off = if (scale <= 1f) Offset.Zero else Offset(
                                (off.x + pan.x).coerceIn(-mx, mx),
                                (off.y + pan.y).coerceIn(-my, my)
                            )
                            onZoom(scale > 1f)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                        go = ev.changes.any { it.pressed }
                    }
                }
            }
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y)
    )
}

package com.aura.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

internal fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")

object LyricsRepo {
    private val tsRe = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?\\]")

    suspend fun load(ctx: Context, title: String, artist: String, durMs: Long, custom: String?): Lyrics? =
        withContext(Dispatchers.IO) {
            val (t, a) = cleanTitle(title, artist)
            val key = (custom ?: "$t|$a").lowercase().hashCode().toString()
            val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }
            val cache = File(dir, "$key.json")
            if (cache.exists()) {
                try {
                    val o = JSONObject(cache.readText())
                    val cached = build(o.str("synced"), o.str("plain"))
                    if (cached != null) return@withContext cached
                } catch (e: Exception) {
                }
            }
            val obj = findBest(t, a, durMs, custom) ?: return@withContext null
            val synced = obj.str("syncedLyrics")
            val plain = obj.str("plainLyrics")
            val lyr = build(synced, plain)
            if (lyr != null) {
                try {
                    cache.writeText(JSONObject().put("synced", synced).put("plain", plain).toString())
                } catch (e: Exception) {
                }
            }
            lyr
        }

    private fun build(synced: String, plain: String): Lyrics? {
        if (synced.isNotBlank()) {
            val l = parseLrc(synced)
            if (l.isNotEmpty()) return Lyrics(l, true)
        }
        if (plain.isNotBlank()) return Lyrics(plain.lines().map { LyricLine(-1L, it) }, false)
        return null
    }

    fun parseLrc(s: String): List<LyricLine> {
        val res = ArrayList<LyricLine>()
        for (raw in s.lines()) {
            val ms = tsRe.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val text = raw.replace(tsRe, "").trim()
            for (m in ms) {
                val mm = m.groupValues[1].toLong()
                val ss = m.groupValues[2].toLong()
                val fr = m.groupValues[3]
                val f = when (fr.length) {
                    0 -> 0L
                    1 -> fr.toLong() * 100
                    2 -> fr.toLong() * 10
                    else -> fr.take(3).toLong()
                }
                res.add(LyricLine((mm * 60 + ss) * 1000 + f, text))
            }
        }
        return res.sortedBy { it.timeMs }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun findBest(t: String, a: String, durMs: Long, custom: String?): JSONObject? {
        val urls = ArrayList<String>()
        if (custom != null) {
            urls.add("https://lrclib.net/api/search?q=" + enc(custom))
        } else {
            if (a.isNotBlank()) urls.add("https://lrclib.net/api/search?track_name=${enc(t)}&artist_name=${enc(a)}")
            urls.add("https://lrclib.net/api/search?q=" + enc("$t $a".trim()))
            urls.add("https://lrclib.net/api/search?track_name=" + enc(t))
        }
        var best: JSONObject? = null
        var bestScore = 0.0
        for (u in urls) {
            val body = httpGet(u) ?: continue
            val arr = try { JSONArray(body) } catch (e: Exception) { continue }
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val s = score(o, t, a, durMs, custom)
                if (s > bestScore) { bestScore = s; best = o }
            }
            if (bestScore >= 0.85) break
        }
        val min = if (custom != null) 0.3 else 0.5
        return if (bestScore >= min) best else null
    }

    private fun score(o: JSONObject, t: String, a: String, durMs: Long, custom: String?): Double {
        val hasLyrics = o.str("syncedLyrics").isNotBlank() || o.str("plainLyrics").isNotBlank()
        if (!hasLyrics) return 0.0
        if (custom != null) {
            val s = sim(norm(o.str("trackName") + " " + o.str("artistName")), norm(custom))
            return 0.3 + s * 0.7 + (if (o.str("syncedLyrics").isNotBlank()) 0.05 else 0.0)
        }
        val st = sim(norm(o.str("trackName")), norm(t))
        val sa = if (a.isBlank()) 0.5 else sim(norm(o.str("artistName")), norm(a))
        val od = o.optDouble("duration", 0.0) * 1000
        val sd = if (durMs <= 0 || od <= 0) 0.5 else (1.0 - abs(od - durMs) / 15000.0).coerceIn(0.0, 1.0)
        var s = st * 0.6 + sa * 0.25 + sd * 0.15
        if (o.str("syncedLyrics").isNotBlank()) s += 0.08
        if (o.optBoolean("instrumental", false)) s -= 0.3
        return s
    }

    private fun httpGet(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Aura/1.0 (Android music player)")
            try {
                if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{Nd}]+"), " ").trim()

    private fun sim(a: String, b: String): Double {
        if (a.isEmpty() && b.isEmpty()) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        val contains = (a.length >= 4 && b.contains(a)) || (b.length >= 4 && a.contains(b))
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = tmp
            }
        }
        val r = 1.0 - dp[b.length].toDouble() / maxOf(a.length, b.length)
        return if (contains) maxOf(r, 0.85) else r
    }

    /** Cleans noisy titles such as "Artist - Song (Official Video) [HD]". */
    fun cleanTitle(title: String, artist: String): Pair<String, String> {
        var t = title.replace(Regex("\\(.*?\\)|\\[.*?\\]|【.*?】"), " ")
        t = t.replace(
            Regex("(?i)\\b(official|video|audio|lyrics?|lyric video|hd|hq|4k|mv|music video|visualizer)\\b"), " "
        )
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', '|')
        var a = artist.trim()
        if (a.equals("<unknown>", true) || a.startsWith("Unknown", true) || a.startsWith("فنان غير")) a = ""
        a = a.replace(Regex("(?i)\\s*-\\s*topic$"), "").trim()
        val parts = t.split(" - ", " – ", " — ", " | ")
        if (parts.size >= 2) {
            val p0 = parts[0].trim()
            if (a.isBlank() || sim(norm(p0), norm(a)) > 0.6) {
                a = p0
                t = parts.drop(1).joinToString(" - ").trim()
            }
        }
        return Pair(t, a)
    }
}

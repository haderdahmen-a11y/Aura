package com.aura.player.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        sp = c.getSharedPreferences("aura", Context.MODE_PRIVATE)
        Lang.mode = sp.getString("lang", "auto") ?: "auto"
    }
    fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun putStr(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun int(k: String, d: Int = 0): Int = sp.getInt(k, d)
    fun putInt(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun bool(k: String, d: Boolean = false): Boolean = sp.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun long(k: String, d: Long = 0L): Long = sp.getLong(k, d)
    fun putLong(k: String, v: Long) { sp.edit().putLong(k, v).apply() }
}

object Lang {
    var mode by mutableStateOf("auto")
    val isAr: Boolean
        get() = when (mode) {
            "ar" -> true
            "en" -> false
            else -> Locale.getDefault().language == "ar"
        }
    fun set(m: String) { mode = m; Prefs.putStr("lang", m) }
}

fun tr(en: String, ar: String): String = if (Lang.isAr) ar else en

object Stats {
    val favs = mutableStateListOf<Long>()
    fun load() {
        favs.clear()
        favs.addAll(Prefs.str("favs", "").split(",").mapNotNull { it.toLongOrNull() })
    }
    fun toggleFav(id: Long) {
        if (favs.contains(id)) favs.remove(id) else favs.add(id)
        Prefs.putStr("favs", favs.joinToString(","))
    }
    fun isFav(id: Long): Boolean = favs.contains(id)
    fun onPlayed(id: Long) {
        Prefs.putInt("pc_$id", Prefs.int("pc_$id", 0) + 1)
        Prefs.putLong("lp_$id", System.currentTimeMillis())
    }
    fun count(id: Long): Int = Prefs.int("pc_$id", 0)
    fun last(id: Long): Long = Prefs.long("lp_$id", 0L)
}

fun toast(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post {
        Toast.makeText(ctx.applicationContext, msg.take(300), Toast.LENGTH_LONG).show()
    }
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

package com.aura.player.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aura.player.data.Downloads
import com.aura.player.data.tr
import com.aura.player.player.AudioFx
import com.aura.player.player.PlayerController
import com.aura.player.player.UiState
import kotlinx.coroutines.delay

@Composable
fun AuraRoot() {
    val ctx = LocalContext.current
    val app = remember { AppState(ctx) }
    val ctrl = remember { PlayerController(ctx) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val mediaPerms = remember {
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    val requestPerms = remember {
        if (Build.VERSION.SDK_INT >= 33) mediaPerms + Manifest.permission.POST_NOTIFICATIONS else mediaPerms
    }
    fun hasMedia(): Boolean = mediaPerms.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        app.granted = hasMedia()
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) AudioFx.retryViz()
    }

    LaunchedEffect(Unit) {
        app.granted = hasMedia()
        if (!app.granted) launcher.launch(requestPerms)
    }
    LaunchedEffect(app.granted, Downloads.done.size) {
        if (app.granted) app.refresh()
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(250)
            if (UiState.foreground) ctrl.tick()
        }
    }
    LaunchedEffect(UiState.resumeVideo) {
        UiState.resumeVideo?.let {
            app.videoTitle = it
            UiState.resumeVideo = null
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Pal.Bg2, Pal.Bg1)))) {
        if (!app.granted) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                Text("Aura", fontSize = 40.sp, color = Pal.Accent2)
                Text(
                    tr("Allow access to your music, videos and photos to get started.", "اسمح بالوصول إلى الموسيقى والفيديوهات والصور للبدء."),
                    textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 16.dp)
                )
                Button(
                    onClick = { launcher.launch(requestPerms) },
                    colors = ButtonDefaults.buttonColors(containerColor = Pal.Accent, contentColor = Color.Black)
                ) { Text(tr("Grant access", "منح الإذن")) }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> LibraryScreen(app, ctrl)
                        1 -> YoutubeScreen(app, ctrl)
                        2 -> GalleryScreen(app)
                        else -> SettingsScreen(app) { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                    }
                }
                MiniPlayer(ctrl) { app.showNow = true }
                NavBar(tab) { tab = it }
            }
        }

        AnimatedVisibility(
            visible = app.showNow && ctrl.item != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            NowPlayingScreen(ctrl, onClose = { app.showNow = false }, onEq = { app.showEq = true })
        }
        if (app.showEq) EqualizerScreen { app.showEq = false }
        val vt = app.videoTitle
        if (vt != null) VideoScreen(vt) { app.videoTitle = null }
        if (app.photoIndex >= 0) PhotoViewer(app.images, app.photoIndex) { app.photoIndex = -1 }
    }
}

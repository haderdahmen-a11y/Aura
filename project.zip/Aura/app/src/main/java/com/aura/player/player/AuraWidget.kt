package com.aura.player.player

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.aura.player.MainActivity
import com.aura.player.R

class AuraWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, build(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val p = PlaybackService.player
        when (intent.action) {
            ACT_PLAY -> {
                if (p == null) openApp(context) else if (p.isPlaying) p.pause() else p.play()
            }
            ACT_NEXT -> p?.seekToNext()
            ACT_PREV -> p?.seekToPrevious()
        }
    }

    companion object {
        const val ACT_PLAY = "com.aura.player.WIDGET_PLAY"
        const val ACT_NEXT = "com.aura.player.WIDGET_NEXT"
        const val ACT_PREV = "com.aura.player.WIDGET_PREV"

        private fun openApp(ctx: Context) {
            val i = Intent(ctx, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }

        private fun action(ctx: Context, act: String, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, code, Intent(ctx, AuraWidget::class.java).setAction(act),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

        fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_aura)
            val p = PlaybackService.player
            val md = p?.mediaMetadata
            rv.setTextViewText(R.id.w_title, md?.title?.toString() ?: "Aura")
            rv.setTextViewText(R.id.w_artist, md?.artist?.toString() ?: "")
            rv.setImageViewResource(R.id.w_play, if (p?.isPlaying == true) R.drawable.ic_pause else R.drawable.ic_play)
            rv.setOnClickPendingIntent(R.id.w_play, action(ctx, ACT_PLAY, 1))
            rv.setOnClickPendingIntent(R.id.w_next, action(ctx, ACT_NEXT, 2))
            rv.setOnClickPendingIntent(R.id.w_prev, action(ctx, ACT_PREV, 3))
            val open = PendingIntent.getActivity(
                ctx, 4, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.w_root, open)
            return rv
        }

        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, AuraWidget::class.java))
                if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx))
            } catch (e: Exception) {
            }
        }
    }
}

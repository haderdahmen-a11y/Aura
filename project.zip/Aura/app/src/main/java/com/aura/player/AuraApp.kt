package com.aura.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.aura.player.data.Prefs
import com.aura.player.data.Stats
import com.aura.player.data.YtState
import com.aura.player.player.AudioFx

class AuraApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        Stats.load()
        AudioFx.init()
        YtState.init(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build()

    companion object {
        lateinit var instance: AuraApp
    }
}

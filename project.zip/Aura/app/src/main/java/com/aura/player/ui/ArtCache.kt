package com.aura.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ArtCache {
    private val cache = LruCache<String, Bitmap>(80)

    suspend fun get(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val key = "$uri@$size"
        cache.get(key)?.let { return it }
        val bmp = withContext(Dispatchers.IO) {
            try {
                ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
            } catch (e: Exception) {
                null
            }
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }
}

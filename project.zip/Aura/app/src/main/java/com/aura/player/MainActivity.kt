package com.aura.player

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.aura.player.player.UiState
import com.aura.player.player.VideoHolder
import com.aura.player.ui.AuraRoot
import com.aura.player.ui.AuraTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            AuraTheme { AuraRoot() }
        }
    }

    override fun onStart() {
        super.onStart()
        UiState.foreground = true
    }

    override fun onStop() {
        super.onStop()
        UiState.foreground = false
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (UiState.videoActive && VideoHolder.player?.isPlaying == true) enterPip()
    }

    fun enterPip() {
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        } catch (e: Exception) {
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        UiState.inPip = isInPictureInPictureMode
    }
}

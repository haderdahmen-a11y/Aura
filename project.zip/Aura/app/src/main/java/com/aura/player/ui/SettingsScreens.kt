package com.aura.player.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aura.player.data.Lang
import com.aura.player.data.YtRepo
import com.aura.player.data.YtState
import com.aura.player.data.toast
import com.aura.player.data.tr
import com.aura.player.player.AudioFx
import kotlinx.coroutines.launch

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(title, color = Pal.Accent2, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        Column(Modifier.fillMaxWidth().glass(20.dp).padding(14.dp)) { content() }
    }
}

@Composable
fun SettingsScreen(app: AppState, onMicRequest: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st by YtState.status.collectAsState()
    var updating by remember { mutableStateOf(false) }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle(tr("Settings", "الإعدادات"))

        Section(tr("Language", "اللغة")) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(tr("Auto", "تلقائي"), Lang.mode == "auto") { Lang.set("auto") }
                Pill("العربية", Lang.mode == "ar") { Lang.set("ar") }
                Pill("English", Lang.mode == "en") { Lang.set("en") }
            }
        }

        Section(tr("Sound", "الصوت")) {
            Row(Modifier.fillMaxWidth().clickable { app.showEq = true }, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Tune, null, tint = Pal.Accent)
                Spacer(Modifier.width(12.dp))
                Text(tr("Equalizer & bass boost", "المعادل وتعزيز البيس"), modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Smooth track transitions (fade)", "انتقال ناعم بين الأغاني (تلاشي)"), modifier = Modifier.weight(1f))
                Switch(
                    checked = AudioFx.fade, onCheckedChange = { AudioFx.setFade(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Pal.Accent2, checkedThumbColor = Color.Black)
                )
            }
        }

        Section("yt-dlp") {
            Text(
                when (st) {
                    0 -> tr("Engine: starting…", "المحرك: قيد التشغيل…")
                    1 -> tr("Engine: ready", "المحرك: جاهز")
                    else -> tr("Engine: error", "المحرك: خطأ")
                },
                color = Color.White.copy(alpha = 0.8f)
            )
            TextButton(onClick = {
                if (updating) return@TextButton
                updating = true
                scope.launch {
                    try {
                        val r = YtRepo.update(ctx)
                        toast(ctx, tr("Updated: ", "تم التحديث: ") + r)
                    } catch (e: Throwable) {
                        toast(ctx, tr("Update failed: ", "فشل التحديث: ") + (e.cause?.message ?: e.message ?: ""))
                    } finally {
                        updating = false
                    }
                }
            }) {
                Text(if (updating) tr("Updating…", "جارٍ التحديث…") else tr("Update yt-dlp (fixes YouTube issues)", "تحديث yt-dlp (يصلح مشاكل يوتيوب)"), color = Pal.Accent)
            }
        }

        Section(tr("Permissions", "الأذونات")) {
            TextButton(onClick = { if (!micOk) onMicRequest() }) {
                Text(
                    if (micOk) tr("Real audio visualizer: enabled", "مصوّر الصوت الحقيقي: مفعّل")
                    else tr("Enable real audio visualizer (microphone permission)", "تفعيل مصوّر الصوت الحقيقي (إذن الميكروفون)"),
                    color = Pal.Accent
                )
            }
            Text(
                tr("The visualizer only reads the player's own audio output, nothing is recorded.", "المصوّر يقرأ مخرجات المشغل نفسه فقط ولا يُسجَّل أي صوت."),
                color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp
            )
            TextButton(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text(tr("Allow floating video window", "السماح بنافذة الفيديو العائمة"), color = Pal.Accent) }
        }

        Section(tr("About", "حول")) {
            Text("Aura 1.0", fontWeight = FontWeight.SemiBold)
            Text(
                tr("Lyrics by LRCLIB \u2022 Downloads by yt-dlp \u2022 Player by Media3", "الكلمات من LRCLIB \u2022 التنزيل عبر yt-dlp \u2022 المشغل Media3"),
                color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun EqualizerScreen(onBack: () -> Unit) {
    BackHandler { onBack() }
    Box(Modifier.fillMaxSize().androidxBg()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                Text(tr("Equalizer", "المعادل"), fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Switch(
                    checked = AudioFx.eqOn, onCheckedChange = { AudioFx.setEnabled(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Pal.Accent2, checkedThumbColor = Color.Black)
                )
                Spacer(Modifier.width(12.dp))
            }

            if (!AudioFx.available) {
                Text(
                    tr("Play any song first, then come back to tune the sound.", "شغّل أي أغنية أولاً ثم عد لضبط الصوت."),
                    color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(20.dp)
                )
            } else {
                LazyRow(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(AudioFx.presets) { p ->
                        Pill(p.first, false) {
                            AudioFx.applyPreset(p.second)
                            if (!AudioFx.eqOn) AudioFx.setEnabled(true)
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).glass(20.dp).padding(16.dp)) {
                    for (b in AudioFx.levels.indices) {
                        val hz = AudioFx.freqs.getOrNull(b) ?: 0
                        val label = if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(label, fontSize = 12.sp, modifier = Modifier.width(64.dp), color = Color.White.copy(alpha = 0.7f))
                            Slider(
                                value = AudioFx.levels[b].toFloat(),
                                onValueChange = { AudioFx.setLevel(b, it.toInt()) },
                                valueRange = AudioFx.minLevel.toFloat()..AudioFx.maxLevel.toFloat(),
                                modifier = Modifier.weight(1f),
                                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Pal.Accent, inactiveTrackColor = Color.White.copy(alpha = 0.2f))
                            )
                            Text("%.0f dB".format(AudioFx.levels[b] / 100f), fontSize = 11.sp, modifier = Modifier.width(44.dp), color = Color.White.copy(alpha = 0.6f))
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).glass(20.dp).padding(16.dp)) {
                    Text(tr("Bass boost", "تعزيز البيس"), fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = AudioFx.bass.toFloat(),
                        onValueChange = { AudioFx.setBass(it.toInt()) },
                        valueRange = 0f..1000f,
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Pal.Pink, inactiveTrackColor = Color.White.copy(alpha = 0.2f))
                    )
                }
            }
        }
    }
}

private fun Modifier.androidxBg(): Modifier =
    this.then(Modifier.background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Pal.Bg2, Pal.Bg1))))
